package org.example.chess;

import java.util.Map;
import java.util.Scanner;

public class Game {

    private String jugador1;
    private String jugador2;
    private Board board;
    private Map<Piece,Integer> remainingPieces;
    private Map<Piece,Integer> deletedPieces;
    private static DeletedPieceManagerListImp deletedList;

    public Game() {
        board = new Board();
        board.placePieces();
        deletedList = new DeletedPieceManagerListImp();
    }

    public void gameStart(Board board){
        board.placePieces();

        jugador1 = entrada.getTexto("Nombre de jugador 1: ");
        jugador2 = entrada.getTexto("Nombre de jugador 2: ");
    }

    public static DeletedPieceManagerListImp getDeletedList() {
        return deletedList;
    }

    public Board getBoard() {
        return board;
    }

    public Map<Piece, Integer> getRemainingPieces() {
        return remainingPieces;
    }

    public Map<Piece, Integer> getDeletedPieces() {
        return deletedPieces;
    }
}
